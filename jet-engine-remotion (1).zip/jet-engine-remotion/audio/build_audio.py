#!/usr/bin/env python3
"""
Original (copyright-free) cinematic music + sound effects for the jet engine video,
generated from scratch with numpy, timed to the script (25.6 s) and mixed around the real voiceover.

 - If audio/voiceover.m4a exists, it is used as the real timing/ducking reference and is mixed in.
 - If not, the music+SFX bed is ducked using the script's speaking windows (SPEECH below).
   Drop your voiceover next to this file as voiceover.m4a, update the CUES, and run again.

Needs: python3, numpy, scipy, ffmpeg.      Run: python3 build_audio.py
Output: ../public/audio/final-mix.m4a  (+ final-mix.wav)
"""
import os, subprocess, tempfile
import numpy as np
from scipy.signal import butter, sosfilt, fftconvolve
import scipy.io.wavfile as wf

HERE = os.path.dirname(os.path.abspath(__file__))
VO_IN = os.path.join(HERE, 'voiceover.m4a')
OUT_DIR = os.path.join(HERE, '..', 'public', 'audio')
os.makedirs(OUT_DIR, exist_ok=True)

SR = 48000
DUR = 25.6                      # 768 frames at 30 fps (the voiceover is 25.59 s)
T = np.arange(int(SR * DUR)) / SR
N = len(T)

# ---- CUES (seconds) - taken from the real voiceover's words and pauses --------------
HOOK_IMPACT = 1.95    # camera arrives at the engine
S2 = 6.0              # "First, powerful fans suck..."      air intake
S3 = 9.52             # "Inside, spinning blades compress"  compression
INJ = 12.40           # "fuel is injected"
IGN = 13.90           # "and ignited"                       controlled ignition
S4 = 17.32            # "Those gases blast backward..."     turbine + exhaust
SHAFT = 19.0          # turbine whine keeps climbing
POWER = 999.0         # (not used in this script)
S5 = 17.32            # exhaust rush starts with the blast
IMPACT = 20.62        # pause before "pushing the airplane forward": big low impact
OUTRO = 22.42         # "That's how a jet engine turns explosions into flight!"
SPEECH = [(0.14, 5.6), (6.0, 9.3), (9.52, 16.76), (17.32, 22.16), (22.42, 25.34)]   # fallback if no voiceover

# ---- helpers -------------------------------------------------------------------
def smoothstep(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)

def E(points, sm=15):
    e = np.interp(T, [p[0] for p in points], [p[1] for p in points])
    return np.clip(sosfilt(butter(2, sm, 'low', fs=SR, output='sos'), e), 0, None)

def filt(x, kind, fc, order=2):
    return sosfilt(butter(order, fc, kind, fs=SR, output='sos'), x, axis=-1)

def bpf(x, lo, hi, order=2):
    return sosfilt(butter(order, [lo, hi], 'band', fs=SR, output='sos'), x, axis=-1)

def sweep(x, fc_t, kind='low', order=2, chunk=1024):
    out = np.zeros_like(x)
    for ch in range(x.shape[0]):
        zi = None
        for i in range(0, N, chunk):
            sos = butter(order, float(np.clip(fc_t[i], 30, SR * 0.45)), kind, fs=SR, output='sos')
            if zi is None:
                zi = np.zeros((sos.shape[0], 2))
            y, zi = sosfilt(sos, x[ch, i:i + chunk], zi=zi)
            out[ch, i:i + chunk] = y
    return out

def white(seed):
    return np.random.default_rng(seed).standard_normal((2, N))

def pink(seed):
    F = np.fft.rfft(white(seed), axis=-1)
    f = np.fft.rfftfreq(N, 1 / SR); f[0] = 1
    p = np.fft.irfft(F / np.sqrt(f), N, axis=-1)
    return p / p.std()

def brown(seed):
    b = filt(white(seed), 'low', 90)
    return b / b.std()

def tone(f_t, harm):
    ph = 2 * np.pi * np.cumsum(f_t) / SR
    s = sum(a * np.sin(h * ph) for h, a in harm)
    return np.stack([s, s])

def boom(t0, f0, f1, tau, amp, namp=0.0, nf=400):
    m = T >= t0
    tt = np.where(m, T - t0, 0)
    f = f1 + (f0 - f1) * np.exp(-tt / 0.15)
    ph = 2 * np.pi * np.cumsum(np.where(m, f, 0)) / SR
    env = np.where(m, np.minimum(1, tt / 0.004) * np.exp(-tt / tau), 0)
    s = np.sin(ph) * env * amp
    if namp:
        nb = filt(white(97)[0], 'low', nf) * np.where(m, np.exp(-tt / (tau * 0.4)), 0)
        s = s + nb / (nb.std() + 1e-9) * namp * 0.3
    return np.stack([s, s])

def rms_db(x):
    return 20 * np.log10(np.sqrt(np.mean(np.square(x))) + 1e-12)

# ==================================================================================
# SOUND EFFECTS  ("low" bus stays under the speech band, "high" bus is ducked by speech)
# ==================================================================================
low = np.zeros((2, N))
high = np.zeros((2, N))

# --- Scene 1, hook: deep rumble bed, whoosh during the opening camera move, impact on arrival
rum_env = E([(0, 0), (0.9, 0.55), (S2 - 0.3, 0.5), (S2 + 1.0, 0.28), (IGN - 0.1, 0.28), (IGN + 0.6, 0.45),
             (S4, 0.5), (S5 + 1.0, 0.8), (OUTRO + 0.5, 0.8), (DUR, 0)])
am = 0.8 + 0.25 * filt(white(12), 'low', 3)
low += filt(brown(11), 'low', 170) * rum_env * am * 0.55

wh = filt(sweep(pink(21), np.interp(T, [0, 1.4, 2.6], [200, 2200, 900]), 'low'), 'high', 150)
high += wh * E([(0, 0), (0.25, 0.3), (1.4, 1.0), (2.5, 0), (2.6, 0)]) * 0.5
low += boom(HOOK_IMPACT, 70, 38, 1.4, 0.45, 0.15)

# --- Scene 2, air intake: suction + rushing air, fan whine that rises with the rotation speed
rush = filt(sweep(pink(31), np.interp(T, [S2 - 0.2, S2 + 3.0, S3 + 0.4], [300, 1800, 1200]), 'low'), 'high', 120)
high += rush * E([(S2 - 0.2, 0), (S2 + 1.6, 0.7), (S3 - 0.6, 1.0), (S3 + 0.8, 0.25), (S3 + 3, 0.12), (S3 + 4, 0)]) * 0.45

fan_hz = 55 + 200 * smoothstep((T - 4.0) / 5.0)                    # same curve as the visual spin-up (4 s -> 9 s)
fan_hz = fan_hz * (1 + 0.12 * smoothstep((T - POWER) / 0.8) * (T < S5 + 0.5))   # small lift when the shaft powers the fan
fan = tone(fan_hz, [(1, 1), (2, 0.7), (3, 0.5), (4, 0.35), (6, 0.2), (8, 0.12)])
high += fan * E([(S2 - 0.1, 0), (S2 + 1.2, 0.5), (S3 + 0.4, 0.7), (S3 + 2, 0.25), (S4, 0.15), (OUTRO, 0.15), (DUR - 1, 0)]) * 0.12

# --- Scene 3, compression: metallic compressor whir + compression whoosh
comp_hz = np.interp(T, [S3, IGN], [320, 900])
comp_am = 0.65 + 0.35 * np.sin(2 * np.pi * np.cumsum(np.interp(T, [S3, IGN], [22, 46])) / SR)
comp = tone(comp_hz, [(1, 1), (2, 0.4), (3, 0.25)]) * comp_am
comp += bpf(white(41), 1500, 4000) * 0.05
high += comp * E([(S3 - 0.1, 0), (S3 + 1.0, 0.5), (IGN, 0.8), (IGN + 1.5, 0.35), (S4, 0.25), (S4 + 1, 0)]) * 0.10

cw = filt(sweep(pink(42), np.interp(T, [S3 - 0.1, S3 + 1.5, S3 + 3.5], [400, 3500, 1500]), 'low'), 'high', 200)
high += cw * E([(S3 - 0.1, 0), (S3 + 1.2, 0.8), (S3 + 2.4, 0.5), (S3 + 3.6, 0)]) * 0.4

# --- Combustion: fuel injection hiss, controlled ignition, steady roar (no explosion)
inj = filt(white(51), 'high', 2500) * (0.6 + 0.4 * (np.sin(2 * np.pi * 16 * T) > 0))
high += inj * E([(INJ - 0.02, 0), (INJ + 0.03, 1.0), (INJ + 1.6, 0.5), (INJ + 2.0, 0)], sm=40) * 0.16
low += boom(IGN, 90, 45, 0.9, 0.55, 0.2, nf=500)
rng = np.random.default_rng(61)
sparks = filt((rng.random((2, N)) > 0.993) * rng.standard_normal((2, N)), 'low', 6000)
high += sparks * np.where(T > IGN, np.exp(-(T - IGN) / 0.25), 0) * 0.5

roar_env = E([(IGN - 0.05, 0), (IGN + 1.5, 0.45), (S4, 0.6), (S5 + 0.5, 1.0), (OUTRO + 0.5, 1.0), (DUR - 0.5, 0)])
turb = 0.75 + 0.25 * filt(white(71), 'low', 6)
low += filt(brown(72), 'low', 280) * roar_env * turb * 0.9
high += bpf(pink(73), 200, 1200) * roar_env * turb * 0.35

# --- Scene 4, turbine + shaft: deep turbine spin that climbs while the shaft drives the fan
tur_hz = np.interp(T, [S4 - 0.1, IMPACT, OUTRO], [140, 380, 300])
tur = tone(tur_hz, [(1, 1), (2, 0.6), (3, 0.4), (5, 0.2)])
high += tur * E([(S4 - 0.1, 0), (S4 + 1.0, 0.6), (SHAFT, 0.8), (S5 + 2.5, 0.6), (DUR - 1.5, 0)]) * 0.10

# --- Scene 5, thrust: exhaust rush, big low-frequency impact on "forward thrust", roar fades out
ex = filt(sweep(pink(81), np.interp(T, [S5, S5 + 2.0, OUTRO, DUR], [500, 2200, 2000, 900]), 'low'), 'high', 100)
high += ex * E([(S5 - 0.2, 0), (S5 + 1.2, 0.7), (IMPACT - 0.4, 1.0), (OUTRO, 0.8), (DUR - 1.0, 0)]) * 0.4
low += boom(IMPACT, 60, 30, 2.0, 0.9, 0.3)

# ==================================================================================
# MUSIC (original, A minor): starts curious, builds through each scene, peaks on thrust, resolves
# ==================================================================================
mus = np.zeros((2, N))
mtof = lambda n: 440 * 2 ** ((n - 69) / 12)

def add(sig, t0, pan=0.0, gain=1.0, bus=None):
    bus = mus if bus is None else bus
    i = int(t0 * SR); n = min(len(sig), N - i)
    if n <= 0:
        return
    bus[0, i:i + n] += sig[:n] * gain * np.sqrt(0.5 * (1 - pan))
    bus[1, i:i + n] += sig[:n] * gain * np.sqrt(0.5 * (1 + pan))

def pad(notes, dur, att, rel, cut, det=0.004):
    n = int((dur + rel) * SR); t = np.arange(n) / SR; sig = np.zeros(n)
    for m in notes:
        for d in (-det, 0, det):
            ph = 2 * np.pi * mtof(m) * (1 + d) * t
            sig += sum(np.sin(h * ph) / h for h in range(1, 7))
    e = np.minimum(1, t / att) * np.where(t < dur, 1, np.clip(1 - (t - dur) / rel, 0, 1))
    return filt(sig * e, 'low', cut) / (len(notes) * 3)

def pluck(f, dec):
    t = np.arange(int(1.2 * SR)) / SR; ph = 2 * np.pi * f * t
    return (np.sin(ph) + .45 * np.sin(2 * ph) + .25 * np.sin(3 * ph) + .12 * np.sin(4 * ph)) * np.exp(-t / dec) * (1 - np.exp(-t / 0.003))

def kick():
    t = np.arange(int(0.5 * SR)) / SR
    return np.sin(2 * np.pi * np.cumsum(45 + 90 * np.exp(-t / 0.03)) / SR) * np.exp(-t / 0.22)

def sub(f, dur):
    t = np.arange(int(dur * SR)) / SR
    return np.sin(2 * np.pi * f * t) * np.minimum(1, t / 0.02) * np.clip(1 - np.maximum(t - (dur - 0.15), 0) / 0.15, 0, 1)

def snare():
    t = np.arange(int(0.35 * SR)) / SR
    nz = bpf(np.random.default_rng(5).standard_normal(len(t)), 1200, 6000)
    return nz * np.exp(-t / 0.12) + 0.6 * np.sin(2 * np.pi * 190 * t) * np.exp(-t / 0.08)

def hat():
    t = np.arange(int(0.12 * SR)) / SR
    return filt(np.random.default_rng(6).standard_normal(len(t)), 'high', 7000) * np.exp(-t / 0.03)

CH = {'Am': [45, 52, 57, 60, 64], 'F': [41, 48, 53, 57, 60], 'G': [43, 50, 55, 59, 62], 'Dm': [38, 45, 50, 53, 57]}
ROOT = {'Am': 33, 'F': 29, 'G': 31, 'Dm': 26}
SECS = [(0, S2, 'Am', 0.25), (S2, S3, 'F', 0.45), (S3, 11.8, 'Am', 0.60), (11.8, IGN, 'G', 0.65),
        (IGN, S4, 'Dm', 0.85), (S4, 19.0, 'F', 1.0), (19.0, IMPACT, 'G', 1.0), (IMPACT, OUTRO, 'Am', 1.0),
        (OUTRO, DUR, 'Am', 0.30)]

for t0, t1, ch, k in SECS:
    d = t1 - t0
    notes = CH[ch]
    gl = 0.5 + 0.5 * k
    cut = 500 + 900 * k
    add(pad(notes, d, 1.2 if t0 == 0 else 0.4, 1.0, cut), t0, -0.3, 0.9 * gl)
    add(pad(notes, d, 1.2 if t0 == 0 else 0.4, 1.0, cut, det=0.007), t0, 0.3, 0.9 * gl)
    if t0 == 0:                                     # hook: dark drone + slow heartbeat
        add(sub(mtof(ROOT[ch]), d), t0, 0, 0.5)
        for b in np.arange(t0 + 1.2, t1 - 0.3, 1.2):
            add(kick(), b, 0, 0.3)
    if k >= 0.45:
        for b in np.arange(t0, t1 - 0.2, 0.6):      # kick + sub on the beat
            add(kick(), b, 0, 0.30 * k)
            add(sub(mtof(ROOT[ch]), 0.5), b, 0, 0.35 * k)
        astep = 0.3 if k < 0.6 else 0.15            # arpeggio gets busier as the energy rises
        up = notes[2:] + [notes[-1] + 12]
        pat = [0, 1, 2, 3, 2, 1, 2, 3]
        for i, b in enumerate(np.arange(t0, t1 - 0.1, astep)):
            add(pluck(mtof(up[pat[i % 8] % len(up)] + 12), 0.2), b, (-0.4, 0.4)[i % 2], 0.10 + 0.07 * k)
    if k >= 0.65:
        for b in np.arange(t0 + 0.3, t1 - 0.1, 0.3):
            add(hat(), b, 0.3, 0.05 * k)
    if k >= 0.9:
        for b in np.arange(t0 + 0.6, t1 - 0.2, 1.2):
            add(snare(), b, 0, 0.12)
    if t0 == OUTRO:                                  # resolution: slow shimmer, no drums
        for i, b in enumerate(np.arange(t0 + 0.1, t1 - 0.5, 0.6)):
            add(pluck(mtof([76, 72, 69, 64][i % 4]), 0.5), b, (-0.5, 0.5)[i % 2], 0.08)

# risers into each scene change + soft hits on the downbeats
for a, b, amp in [(4.6, S2, 0.35), (8.7, S3, 0.4), (12.4, IGN, 0.5), (16.2, S4, 0.6), (19.6, IMPACT, 0.8)]:
    rz = sweep(pink(int(a * 10)), np.interp(T, [a, b], [300, 7000]), 'low')
    mus += rz * E([(a, 0), (b - 0.02, 1.0), (b, 0), (b + 1, 0)], sm=60) * amp * 0.6
for t, amp in [(S2, 0.5), (S3, 0.55), (IGN, 0.45), (S4, 0.7), (IMPACT, 0.9), (OUTRO, 0.4)]:
    add(sub(mtof(33), 1.2) * np.exp(-np.arange(int(1.2 * SR)) / SR / 0.5), t, 0, amp * 0.5)
    add(kick(), t, 0, amp * 0.6)

# hall reverb, fade out with the ending
rng = np.random.default_rng(3)
irn = int(2.2 * SR); tt = np.arange(irn) / SR
ir = rng.standard_normal((2, irn)) * np.exp(-tt / 0.55)
ir[:, :int(0.02 * SR)] = 0
ir /= np.sqrt((ir ** 2).sum(axis=1, keepdims=True))
wet = np.stack([fftconvolve(mus[c], ir[c])[:N] for c in range(2)])
mus = 0.8 * mus + 0.35 * wet * 6
mus *= np.clip(np.minimum(1, (DUR - T) / 1.8), 0, 1)
mus *= smoothstep(T / 1.0) * 0.8 + 0.2

# ==================================================================================
# VOICEOVER (optional) + MIX
# ==================================================================================
HAVE_VO = os.path.exists(VO_IN)
hop = SR // 100
if HAVE_VO:
    tmp = tempfile.mkdtemp(); vo_wav = os.path.join(tmp, 'vo.wav')
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', VO_IN, '-ar', str(SR), '-ac', '1', vo_wav], check=True)
    _, vo = wf.read(vo_wav)
    vo = vo.astype(np.float64) / 32768
    vo = np.pad(vo, (0, max(0, N - len(vo))))[:N]
    vo = sosfilt(butter(2, 70, 'high', fs=SR, output='sos'), vo)
    db = np.array([20 * np.log10(np.sqrt(np.mean(vo[i:i + 3 * hop] ** 2)) + 1e-9) for i in range(0, N - 3 * hop, hop)])
    gate = smoothstep((db + 48) / 20)
else:
    vo = np.zeros(N)
    t100 = np.arange(N // hop) * 0.01
    gate = np.zeros(len(t100))
    for a, b in SPEECH:
        gate = np.maximum(gate, ((t100 >= a) & (t100 <= b)).astype(float))
g = np.zeros_like(gate); cur = 0.0
for i, x in enumerate(gate):
    a = 1 - np.exp(-1 / (0.03 * 100)) if x > cur else 1 - np.exp(-1 / (0.45 * 100))   # fast attack, slow release
    cur += a * (x - cur); g[i] = cur
G = np.interp(T, np.arange(len(g)) * 0.01, g)

mus *= 10 ** ((-21 - rms_db(mus)) / 20)
low *= 10 ** ((-26 - rms_db(low)) / 20)
high *= 10 ** ((-30 - rms_db(high)) / 20)

mus_d = mus * (1 - 0.55 * G)            # music dips ~7 dB whenever the narrator speaks
high_d = high * (1 - 0.50 * G)          # mid/high SFX dip ~6 dB so they never mask words
low_d = low * (1 - 0.15 * G)            # sub/low SFX sit below the speech band
bed = mus_d + low_d + high_d

if HAVE_VO:
    mix = np.stack([vo, vo]) * 0.85 + bed
else:
    mix = bed
mix = np.tanh(mix * 0.9) / np.tanh(0.9)
mix *= 0.89 / np.abs(mix).max()

# ---- report: how far below the voice (a typical -15 dBFS narrator) is each layer while speech plays ----
speech = G > 0.6
ref_voice_band = rms_db(bpf(vo, 300, 4000)[speech]) if HAVE_VO else -21.0
print('reference narrator voice-band level: %.1f dB (%s)' % (ref_voice_band, 'real voiceover' if HAVE_VO else 'typical narrator, no file'))
for name, bus in [('music', mus_d), ('sfx low', low_d), ('sfx high', high_d)]:
    print('  %-9s %.1f dB under the voice in the speech band' % (name, ref_voice_band - rms_db(bpf(bus, 300, 4000)[:, speech])))

wav = os.path.join(OUT_DIR, 'final-mix.wav')
wf.write(wav, SR, (mix.T * 32767).astype(np.int16))
af = 'loudnorm=I=-16:TP=-1.5:LRA=11' if HAVE_VO else 'volume=0dB'
subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', wav, '-af', af, '-ar', '48000', '-c:a', 'aac', '-b:a', '192k',
                os.path.join(OUT_DIR, 'final-mix.m4a')], check=True)
print('wrote', os.path.join(OUT_DIR, 'final-mix.m4a'), '| voiceover mixed in:', HAVE_VO)
