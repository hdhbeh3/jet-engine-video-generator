import {AbsoluteFill, Audio, staticFile, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Montserrat';
import * as THREE from 'three';
import {Scene} from './Scene';
import {A0, ENGINE_M, clamp, easeOut, makeCamera} from './rig';
import {CALLOUTS, labelOpacity} from './timeline';

const {fontFamily} = loadFont('normal', {weights: ['600'], subsets: ['latin']});

const FONT = 28;
const CHAR_W = 22; // estimated width of one caps character incl. letter spacing
const LINE_H = 34;
const MARGIN = 72;
const TITLE_BOTTOM = 400; // labels never go above this, so they can't touch the title
const GAP = 26;

export const Video = () => {
  const frame = useCurrentFrame();
  const cam = makeCamera(frame);
  const titleIn = easeOut(frame / 18);

  // project each visible callout's anchor to the screen
  const items = CALLOUTS.filter((c) => labelOpacity(c, frame) > 0).map((c) => {
    const [x, R] = c.anchor;
    const v = new THREE.Vector3(x, R * Math.sin(A0), R * Math.cos(A0)).applyMatrix4(ENGINE_M).project(cam);
    return {
      c,
      op: labelOpacity(c, frame),
      ax: ((v.x + 1) / 2) * 1080,
      ay: ((1 - v.y) / 2) * 1920,
      h: c.lines.length * LINE_H,
      w: Math.max(...c.lines.map((l) => l.length)) * CHAR_W,
      ey: 0,
    };
  });

  // stack labels per side with a fixed gap so no two labels or leader ends can overlap
  (['left', 'right'] as const).forEach((side) => {
    let prev = -1e9;
    items
      .filter((i) => i.c.side === side)
      .sort((a, b) => a.ay - b.ay)
      .forEach((it) => {
        let ey = clamp(it.ay, TITLE_BOTTOM + it.h, 1780);
        ey = Math.max(ey, prev + it.h + GAP);
        it.ey = ey;
        prev = ey;
      });
  });

  return (
    <AbsoluteFill
      style={{
        backgroundColor: '#0A2A78',
        backgroundImage:
          'linear-gradient(rgba(130,175,255,0.16) 1px, transparent 1px), linear-gradient(90deg, rgba(130,175,255,0.16) 1px, transparent 1px)',
        backgroundSize: '54px 54px',
      }}
    >
      {/* voiceover + music + SFX, already mixed (see audio/build_audio.py) */}
      <Audio src={staticFile('audio/final-mix.m4a')} />
      <Scene />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 55%, rgba(0,0,0,0) 45%, rgba(3,12,45,0.75) 100%)'}} />

      <div
        style={{
          position: 'absolute', left: MARGIN, top: 110, width: 700, color: '#fff', fontFamily,
          fontWeight: 600, fontSize: 88, lineHeight: 1.05, letterSpacing: -2,
          opacity: titleIn, transform: `translateY(${(1 - titleIn) * 24}px)`,
        }}
      >
        How a Jet<br />Engine Works
      </div>

      <svg width={1080} height={1920} style={{position: 'absolute', inset: 0}}>
        {items.map(({c, op, ax, ay, ey, w}) => {
          const left = c.side === 'left';
          const xs = left ? MARGIN : 1080 - MARGIN;
          const xe = left ? MARGIN + w + 18 : 1080 - MARGIN - w - 18;
          return (
            <g key={c.id} opacity={op}>
              <polyline
                points={`${ax},${ay} ${xe},${ey} ${xs},${ey}`}
                fill="none" stroke="#fff" strokeWidth={3} pathLength={1}
                strokeDasharray={1} strokeDashoffset={1 - op}
              />
              <circle cx={ax} cy={ay} r={9} fill="#fff" />
              <circle cx={ax} cy={ay} r={16} fill="none" stroke="#fff" strokeWidth={2} opacity={0.6} />
              {c.lines.map((line, li) => (
                <text
                  key={li} x={xs} y={ey - 14 - (c.lines.length - 1 - li) * LINE_H}
                  fill="#fff" fontFamily={fontFamily} fontWeight={600} fontSize={FONT} letterSpacing={1.5}
                  textAnchor={left ? 'start' : 'end'}
                >
                  {line}
                </text>
              ))}
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};
