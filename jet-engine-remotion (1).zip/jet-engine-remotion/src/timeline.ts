import {clamp, smooth} from './rig';

// ---- TIMING TAKEN FROM THE REAL VOICEOVER (25.6 s = 768 frames at 30 fps) ----
//  0.1-5.6 s   "This machine can push a massive airplane ... exploding fuel!"   hook, no labels
//  6.0-9.3 s   "First, powerful fans suck huge amounts of air into the engine." FAN
//  9.5-11.6 s  "Inside, spinning blades compress the air,"                       COMPRESSOR
// 11.6-14.0 s  "then fuel is injected and ignited,"                              FUEL INJECTORS (+ COMBUSTION CHAMBER at 13.4 s)
// 14.0-16.8 s  "creating extremely hot, expanding gases."                        combustion stays lit
// 17.3-20.6 s  "Those gases blast backward at incredible speed,"                 TURBINE + EXHAUST NOZZLE
// 20.6-22.2 s  "pushing the airplane forward."                                   THRUST arrow + label
// 22.4-25.3 s  "That's how a jet engine turns explosions into flight!"           whole engine, last 1 s still
// -----------------------------------------------------------------------------

export type Callout = {
  id: string;
  lines: string[];
  anchor: [number, number]; // [position along the engine axis, radius]
  side: 'left' | 'right';
  s: number;
  e: number;
};

export const CALLOUTS: Callout[] = [
  {id: 'fan', lines: ['FAN'], anchor: [-2.35, 0.8], side: 'left', s: 180, e: 286},
  {id: 'comp', lines: ['COMPRESSOR'], anchor: [-1.3, 0.55], side: 'right', s: 286, e: 348},
  {id: 'inj', lines: ['FUEL', 'INJECTORS'], anchor: [-0.5, 0.52], side: 'left', s: 348, e: 518},
  {id: 'comb', lines: ['COMBUSTION', 'CHAMBER'], anchor: [0.1, 0.45], side: 'right', s: 402, e: 518},
  {id: 'turb', lines: ['TURBINE'], anchor: [1.1, 0.5], side: 'left', s: 518, e: 619},
  {id: 'noz', lines: ['EXHAUST', 'NOZZLE'], anchor: [2.7, 0.35], side: 'right', s: 518, e: 619},
  {id: 'thr', lines: ['THRUST'], anchor: [0.5, 1.75], side: 'left', s: 619, e: Infinity},
];

// which engine parts glow while the narrator talks about them
const SEGS = [
  {s: 180, e: 286, parts: ['fan']},
  {s: 286, e: 348, parts: ['comp']},
  {s: 348, e: 518, parts: ['inj']},
  {s: 402, e: 518, parts: ['comb']},
  {s: 518, e: 619, parts: ['turb', 'nozzle']},
];

// how strongly the machine is dimmed to put the spotlight on the active part(s)
export const focus = (f: number) => smooth((f - 170) / 15) * (1 - smooth((f - 640) / 30));

// 0..1: is this part the one being explained right now
export const act = (part: string, f: number) =>
  Math.max(0, ...SEGS.filter((g) => g.parts.includes(part)).map((g) => smooth((f - g.s + 6) / 12) * smooth((g.e + 6 - f) / 12)));

export const labelOpacity = (c: Callout, f: number) => {
  if (f < c.s || f >= c.e) return 0;
  return smooth((f - c.s) / 9) * (c.e === Infinity ? 1 : smooth((c.e - f) / 9));
};

export const ignite = (f: number) => clamp((f - 414) / 16); // "ignited" at about 13.9 s
export const SPRAY_START = 372; // "fuel is injected" at about 12.4 s
export const THRUST_START = 619; // "pushing the airplane forward" at 20.6 s
