import {useEffect, useMemo} from 'react';
import {useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {A0, PHI0, ROT, camAt, clockAt, easeOut, smooth, spinAt} from './rig';
import {SPRAY_START, THRUST_START, act, focus, ignite} from './timeline';

const WHITE = new THREE.Color('#F4F6FA');
const DIM = new THREE.Color('#7F93BD');
const PARTS = ['shell', 'fan', 'comp', 'inj', 'comb', 'turb', 'nozzle', 'core'];

const lathe = (pts: [number, number][]) =>
  new THREE.LatheGeometry(pts.map(([x, r]) => new THREE.Vector2(r, x)), 64, PHI0, Math.PI * 1.5);

// ---------- flow lines ------------------------------------------------------
const X0 = -4.0;
const X1 = 4.6;
const N = 120;
type Tab = [number, number][];
const interp = (tab: Tab, x: number) => {
  if (x <= tab[0][0]) return tab[0][1];
  for (let i = 1; i < tab.length; i++) {
    if (x <= tab[i][0]) {
      const t = (x - tab[i - 1][0]) / (tab[i][0] - tab[i - 1][0]);
      return tab[i - 1][1] + (tab[i][1] - tab[i - 1][1]) * smooth(t);
    }
  }
  return tab[tab.length - 1][1];
};
const CORE: Tab = [[-4, 1.25], [-2.8, 1.1], [-2.2, 1], [-0.6, 0.85], [0.6, 0.9], [1.8, 0.8], [3, 0.6], [3.8, 0.8], [4.6, 1.2]];
const BYP: Tab = [[-4, 1], [-3, 0.95], [-2.4, 1], [1.8, 1], [2.8, 0.6], [3.5, 0.6], [4.6, 0.95]];
const CORE_R = [0.16, 0.28, 0.4, 0.22, 0.34, 0.4, 0.2, 0.3];
const BYP_R = [0.85, 0.95, 1.05, 1.15, 0.9, 1.0, 1.1, 0.8];

const LINES = Array.from({length: 16}, (_, i) => {
  const core = i < 8;
  const j = i % 8;
  const r0 = core ? CORE_R[j] : BYP_R[j];
  const ang = A0 - 0.65 + (1.3 * ((j * 3) % 8)) / 7;
  const pts: THREE.Vector3[] = [];
  for (let k = 0; k <= N; k++) {
    const x = X0 + ((X1 - X0) * k) / N;
    const r = r0 * interp(core ? CORE : BYP, x);
    pts.push(new THREE.Vector3(x, r * Math.sin(ang), r * Math.cos(ang)));
  }
  return {idx: i, core, pts};
});

// how far along the engine the flow has travelled at each moment of the script
const KEYS: [number, number][] = [[180, -4.1], [286, -2.3], [348, -0.7], [440, 0.9], [518, 1.1], [640, 4.7]];
const xHead = (f: number) => {
  if (f <= KEYS[0][0]) return KEYS[0][1];
  for (let i = 1; i < KEYS.length; i++) {
    if (f <= KEYS[i][0]) {
      const t = (f - KEYS[i - 1][0]) / (KEYS[i][0] - KEYS[i - 1][0]);
      return KEYS[i - 1][1] + (KEYS[i][1] - KEYS[i - 1][1]) * smooth(t);
    }
  }
  return KEYS[KEYS.length - 1][1];
};

const ORANGE = new THREE.Color('#FF8A1F');
const RED = new THREE.Color('#B3120F');
const heatAt = (core: boolean, x: number) =>
  core ? smooth((x + 2.2) / 1.8) * (1 - 0.6 * smooth((x - 3.4) / 1.2)) : 0.2 * smooth((x - 1.8) / 1.5);

const Flow = ({l, frame, clock}: {l: (typeof LINES)[number]; frame: number; clock: number}) => {
  const head = xHead(frame - (l.idx % 4) * 2);
  const data = useMemo(() => {
    const pts = l.pts.filter((p) => p.x <= head);
    if (pts.length < 3) return null;
    const g = new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), pts.length * 2, 0.028, 5, false);
    const pos = g.attributes.position;
    const col = new Float32Array(pos.count * 3);
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      c.copy(ORANGE).lerp(RED, heatAt(l.core, pos.getX(i)));
      col.set([c.r, c.g, c.b], i * 3);
    }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return {g, pts};
  }, [l, head]);
  useEffect(() => () => data?.g.dispose(), [data]);
  if (!data) return null;
  const {g, pts} = data;
  const n = pts.length;
  const pulse = (k: number) => {
    const u = (clock * 0.011 + l.idx * 0.13 + k * 0.5) % 1;
    const f = u * (n - 1);
    const i0 = Math.floor(f);
    return pts[i0].clone().lerp(pts[Math.min(i0 + 1, n - 1)], f - i0);
  };
  return (
    <group>
      <mesh geometry={g}>
        <meshBasicMaterial vertexColors toneMapped={false} />
      </mesh>
      {[0, 1].map((k) => (
        <mesh key={k} position={pulse(k)}>
          <sphereGeometry args={[0.05, 10, 10]} />
          <meshBasicMaterial color="#FFE2B0" toneMapped={false} />
        </mesh>
      ))}
      <mesh position={pts[n - 1]}>
        <sphereGeometry args={[0.07, 10, 10]} />
        <meshBasicMaterial color="#FFF4DC" toneMapped={false} />
      </mesh>
    </group>
  );
};

// ---------- engine ----------------------------------------------------------
const Blades = ({x, r0, r1, n, spin, chord, mat}: {x: number; r0: number; r1: number; n: number; spin: number; chord: number; mat: THREE.Material}) => (
  <group position={[x, 0, 0]} rotation={[spin, 0, 0]}>
    {Array.from({length: n}, (_, i) => (
      <group key={i} rotation={[(i / n) * Math.PI * 2, 0, 0]}>
        <mesh position={[0, (r0 + r1) / 2, 0]} rotation={[0, 0.6, 0]} material={mat}>
          <boxGeometry args={[0.035, r1 - r0, chord]} />
        </mesh>
      </group>
    ))}
    <mesh rotation={[0, 0, Math.PI / 2]} material={mat}>
      <cylinderGeometry args={[r0 + 0.02, r0 + 0.02, 0.1, 20]} />
    </mesh>
  </group>
);

const Engine = ({frame}: {frame: number}) => {
  const clock = clockAt(frame);
  const mats = useMemo(
    () =>
      Object.fromEntries(
        PARTS.map((p) => [p, new THREE.MeshStandardMaterial({roughness: 0.9, side: THREE.DoubleSide})])
      ) as Record<string, THREE.MeshStandardMaterial>,
    []
  );
  const g = useMemo(
    () => ({
      shell: lathe([[-3.1, 1.12], [-3.02, 1.26], [-2.8, 1.33], [-1.0, 1.33], [1.6, 1.3], [2.3, 1.12], [2.9, 0.86], [3.05, 0.8]]),
      comp: lathe([[-2.1, 0.68], [-1.4, 0.62], [-0.6, 0.56]]),
      comb: lathe([[-0.6, 0.56], [-0.3, 0.68], [0.5, 0.68], [0.7, 0.6]]),
      liner: lathe([[-0.5, 0.46], [0.6, 0.46]]),
      turb: lathe([[0.7, 0.6], [2.0, 0.5]]),
      noz: lathe([[2.0, 0.5], [3.0, 0.34]]),
    }),
    []
  );
  const F = focus(frame);
  PARTS.forEach((p) => {
    const a = act(p, frame);
    const m = mats[p];
    m.color.copy(WHITE).lerp(DIM, F * (1 - a) * 0.6);
    const hot = p === 'comb';
    m.emissive.set(hot ? '#FF4A10' : '#FFA040');
    m.emissiveIntensity = F * a * (hot ? 0.9 : 0.5);
  });

  const ig = ignite(frame);
  const ap = easeOut((frame - THRUST_START) / 18); // thrust arrow grows in
  const spin = spinAt(frame);
  const spinC = spin * 1.7;
  const sinA = Math.sin(A0);
  const cosA = Math.cos(A0);
  const inj = Array.from({length: 6}, (_, i) => {
    const a = A0 - 0.7 + (1.4 * i) / 5;
    return [-0.5, 0.5 * Math.sin(a), 0.5 * Math.cos(a)] as [number, number, number];
  });

  return (
    <group rotation={[0, 0, ROT]}>
      <mesh geometry={g.shell} material={mats.shell} rotation={[0, 0, -Math.PI / 2]} />
      <mesh geometry={g.comp} material={mats.comp} rotation={[0, 0, -Math.PI / 2]} />
      <mesh geometry={g.comb} material={mats.comb} rotation={[0, 0, -Math.PI / 2]} />
      <mesh geometry={g.liner} material={mats.comb} rotation={[0, 0, -Math.PI / 2]} />
      <mesh geometry={g.turb} material={mats.turb} rotation={[0, 0, -Math.PI / 2]} />
      <mesh geometry={g.noz} material={mats.noz} rotation={[0, 0, -Math.PI / 2]} />

      {/* fan + spinner */}
      <Blades x={-2.35} r0={0.3} r1={1.25} n={18} spin={spin} chord={0.28} mat={mats.fan} />
      <mesh position={[-2.62, 0, 0]} rotation={[0, 0, Math.PI / 2]} material={mats.fan}>
        <coneGeometry args={[0.32, 0.65, 24]} />
      </mesh>

      {/* compressor stages */}
      {[
        [-1.85, 0.6],
        [-1.55, 0.58],
        [-1.25, 0.56],
        [-0.95, 0.54],
        [-0.7, 0.52],
      ].map(([x, r1]) => (
        <Blades key={x} x={x} r0={0.14} r1={r1} n={14} spin={spinC} chord={0.14} mat={mats.comp} />
      ))}

      {/* fuel injectors */}
      {inj.map((p, i) => (
        <group key={i} position={p}>
          <mesh rotation={[0, 0, Math.PI / 2]} material={mats.inj}>
            <cylinderGeometry args={[0.04, 0.04, 0.28, 12]} />
          </mesh>
          <mesh position={[0.15, 0, 0]} material={mats.inj}>
            <sphereGeometry args={[0.065, 12, 12]} />
          </mesh>
        </group>
      ))}


      {/* golden fuel spray from the injectors into the compressed air */}
      {frame >= SPRAY_START &&
        inj.map((p, i) =>
          [0, 1, 2, 3].map((k) => {
            const u = ((clock - SPRAY_START) * 0.018 + k * 0.25 + i * 0.07) % 1;
            const a = A0 - 0.7 + (1.4 * i) / 5;
            const rr = 0.5 - 0.14 * u;
            return (
              <mesh key={`${i}-${k}`} position={[-0.35 + u * 0.8, rr * Math.sin(a), rr * Math.cos(a)]}>
                <sphereGeometry args={[0.03, 8, 8]} />
                <meshBasicMaterial color="#FFD24A" toneMapped={false} />
              </mesh>
            );
          })
        )}

      {/* flame in the combustion chamber */}
      <mesh position={[0.05, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.36, 0.36, 1.0, 24]} />
        <meshBasicMaterial color="#FF7A1A" transparent opacity={ig * 0.9} toneMapped={false} />
      </mesh>
      <pointLight position={[0.05, 0, 0]} color="#FF6A1A" intensity={ig * 3} distance={3} />

      {/* turbine stages */}
      {[0.95, 1.25, 1.55].map((x) => (
        <Blades key={x} x={x} r0={0.14} r1={0.48} n={12} spin={spinC} chord={0.14} mat={mats.turb} />
      ))}

      {/* shaft + nozzle plug */}
      <mesh position={[-0.3, 0, 0]} rotation={[0, 0, Math.PI / 2]} material={mats.core}>
        <cylinderGeometry args={[0.12, 0.12, 4.0, 16]} />
      </mesh>
      <mesh position={[2.65, 0, 0]} rotation={[0, 0, -Math.PI / 2]} material={mats.nozzle}>
        <coneGeometry args={[0.28, 1.3, 24]} />
      </mesh>

      {/* thrust arrow, pointing forward (towards the nose) */}
      {ap > 0 && (
        <group position={[0, 1.75 * sinA, 1.75 * cosA]}>
          <mesh position={[1.6 - 1.1 * ap, 0, 0]} rotation={[0, 0, Math.PI / 2]} scale={[1, ap, 1]}>
            <cylinderGeometry args={[0.07, 0.07, 2.2, 12]} />
            <meshBasicMaterial color="#FFC266" toneMapped={false} />
          </mesh>
          <mesh position={[1.6 - 2.2 * ap - 0.2, 0, 0]} rotation={[0, 0, Math.PI / 2]}>
            <coneGeometry args={[0.22, 0.4, 16]} />
            <meshBasicMaterial color="#FFC266" toneMapped={false} />
          </mesh>
        </group>
      )}

      {LINES.map((l) => (
        <Flow key={l.idx} l={l} frame={frame} clock={clock} />
      ))}
    </group>
  );
};

const Rig = ({frame}: {frame: number}) => {
  const {camera} = useThree();
  const {pos, look} = camAt(frame);
  camera.position.set(...pos);
  camera.lookAt(...look);
  camera.updateMatrixWorld();
  return null;
};

export const Scene = () => {
  const frame = useCurrentFrame();
  return (
    <ThreeCanvas width={1080} height={1920} camera={{fov: 35, near: 0.1, far: 100}} style={{background: 'transparent'}}>
      <Rig frame={frame} />
      <ambientLight intensity={0.9} />
      <hemisphereLight args={['#BFD4FF', '#1A3C8F', 0.5]} />
      <directionalLight position={[5, 9, 6]} intensity={1.6} />
      <directionalLight position={[-6, 4, -3]} intensity={0.5} color="#9DB8FF" />
      <Engine frame={frame} />
    </ThreeCanvas>
  );
};
