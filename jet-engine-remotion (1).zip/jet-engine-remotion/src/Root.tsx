import {Composition} from 'remotion';
import {Video} from './Video';

// 25.6 seconds at 30 fps = 768 frames, matched to the real voiceover
export const Root = () => (
  <Composition id="JetEngine" component={Video} durationInFrames={768} fps={30} width={1080} height={1920} />
);
