import os
import numpy as np
import wave

os.makedirs("render", exist_ok=True)
sample_rate = 48000
duration = 25.6
count = int(sample_rate * duration)
t = np.arange(count, dtype=np.float32) / sample_rate

# Low cinematic engine bed, a soft rising air rush, and restrained pulses.
fade_in = np.clip(t / 2.0, 0, 1)
fade_out = np.clip((duration - t) / 2.0, 0, 1)
envelope = fade_in * fade_out

hum = 0.055 * np.sin(2*np.pi*55*t) + 0.025 * np.sin(2*np.pi*82.4*t)
hum += 0.012 * np.sin(2*np.pi*110*t)

# Filtered-noise-like air texture using a smoothed random signal.
rng = np.random.default_rng(7)
noise = rng.normal(0, 1, count).astype(np.float32)
kernel = np.ones(240, dtype=np.float32) / 240
air = np.convolve(noise, kernel, mode="same").astype(np.float32)
air_env = np.clip((t - 1.0) / 3.0, 0, 1) * np.clip((duration - t) / 4.0, 0, 1)
air = air / (np.max(np.abs(air)) + 1e-8) * 0.10 * air_env

# Small transition accents; deliberately quiet under narration.
pulses = np.zeros(count, dtype=np.float32)
for when in (3.0, 8.0, 14.0, 20.0):
    start = int(when * sample_rate)
    length = min(int(0.35 * sample_rate), count - start)
    if length > 0:
        x = np.arange(length, dtype=np.float32) / sample_rate
        pulses[start:start+length] += 0.08 * np.sin(2*np.pi*(95-140*x)*x) * np.exp(-x*12)

mono = np.clip((hum + air + pulses) * envelope, -0.8, 0.8)
stereo = np.column_stack((mono, mono)).astype(np.float32)
pcm = (stereo * 32767).astype("<i2")

with wave.open("render/music_sfx.wav", "wb") as wf:
    wf.setnchannels(2)
    wf.setsampwidth(2)
    wf.setframerate(sample_rate)
    wf.writeframes(pcm.tobytes())

print("Created render/music_sfx.wav")
