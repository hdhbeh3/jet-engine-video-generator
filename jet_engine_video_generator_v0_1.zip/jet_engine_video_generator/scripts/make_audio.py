import math
import os
import wave
import numpy as np

# Creates a 25.6-second procedural engine ambience / whoosh / ignition bed.
# The user's voiceover is mixed separately by the GitHub Actions workflow.
SAMPLE_RATE = 48000
DURATION = 25.6
N = int(SAMPLE_RATE * DURATION)
t = np.arange(N, dtype=np.float32) / SAMPLE_RATE
rng = np.random.default_rng(7)

def smooth_gate(start, end, fade=0.35):
    a = np.clip((t - start) / fade, 0, 1)
    b = np.clip((end - t) / fade, 0, 1)
    return a * b

# Low turbine-like hum with slowly changing harmonics.
hum = (
    0.12*np.sin(2*np.pi*(48 + 2.5*np.sin(2*np.pi*0.08*t))*t) +
    0.055*np.sin(2*np.pi*96*t) +
    0.025*np.sin(2*np.pi*144*t)
)
# Soft broadband air noise.
noise = rng.normal(0, 1, N).astype(np.float32)
kernel = np.ones(180, dtype=np.float32) / 180
air = np.convolve(noise, kernel, mode="same")
air /= max(float(np.max(np.abs(air))), 1e-6)
air *= 0.11

# Intake whoosh and combustion/exhaust accents.
whoosh = np.zeros(N, dtype=np.float32)
for start, end, amp in [(0.4,4.5,0.22),(6.0,10.0,0.16),(13.5,18.5,0.20),(20.0,25.3,0.18)]:
    gate = smooth_gate(start, end, 0.7)
    sweep = np.sin(2*np.pi*(90*t + 55*(t-start)**2))
    whoosh += amp * gate * sweep

# Short ignition-like low thumps, softened to avoid harsh peaks.
thumps = np.zeros(N, dtype=np.float32)
for sec in [8.0, 13.8, 18.8]:
    idx = int(sec*SAMPLE_RATE)
    length = min(int(0.45*SAMPLE_RATE), N-idx)
    if length > 0:
        tt = np.arange(length, dtype=np.float32)/SAMPLE_RATE
        env = np.exp(-tt*9)
        thumps[idx:idx+length] += 0.22*env*np.sin(2*np.pi*(65-25*tt)*tt)

mix = hum + air + whoosh + thumps
fade_in = np.clip(t/0.8, 0, 1)
fade_out = np.clip((DURATION-t)/1.0, 0, 1)
mix *= fade_in * fade_out
peak = max(float(np.max(np.abs(mix))), 1e-6)
mix = np.clip(mix * (0.72/peak), -0.95, 0.95)
stereo = np.stack([mix, mix], axis=1)
pcm = (stereo * 32767).astype("<i2")

os.makedirs("render", exist_ok=True)
with wave.open("render/music_sfx.wav", "wb") as wf:
    wf.setnchannels(2)
    wf.setsampwidth(2)
    wf.setframerate(SAMPLE_RATE)
    wf.writeframes(pcm.tobytes())

print("Created render/music_sfx.wav")
