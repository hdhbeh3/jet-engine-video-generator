import bpy, math, os
from mathutils import Vector

# ---------- Reset and render settings ----------
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)

scene = bpy.context.scene
# Blender 5.0 uses BLENDER_EEVEE (not BLENDER_EEVEE_NEXT).
scene.render.engine = 'BLENDER_EEVEE'
scene.eevee.taa_render_samples = 16
scene.render.resolution_x = 1080
scene.render.resolution_y = 1920
scene.render.resolution_percentage = 100
scene.render.fps = 30
scene.frame_start = 1
scene.frame_end = 768  # 25.6 seconds at 30 fps
scene.render.image_settings.file_format = 'PNG'
scene.render.film_transparent = False
scene.world.color = (0.012, 0.018, 0.035)
scene.view_settings.view_transform = 'AgX'

os.makedirs("render", exist_ok=True)
scene.render.filepath = os.path.abspath("render/frame_")

# ---------- Materials ----------
def mat(name, color, metallic=0.0, rough=0.35, emission=None, strength=0.0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get("Principled BSDF")
    bs.inputs["Base Color"].default_value = (*color, 1)
    bs.inputs["Metallic"].default_value = metallic
    bs.inputs["Roughness"].default_value = rough
    if emission:
        bs.inputs["Emission Color"].default_value = (*emission, 1)
        bs.inputs["Emission Strength"].default_value = strength
    return m

titanium = mat("Brushed titanium", (0.22,0.29,0.38), 0.82, 0.25)
dark = mat("Engine graphite", (0.025,0.04,0.065), 0.65, 0.3)
steel = mat("Blade steel", (0.48,0.62,0.72), 0.78, 0.2)
blue = mat("Cold airflow blue", (0.02,0.38,1.0), 0.1, 0.25, (0.01,0.18,1.0), 2.5)
orange = mat("Combustion amber", (1.0,0.18,0.015), 0.1, 0.25, (1.0,0.07,0.005), 5.0)
yellow = mat("Hot exhaust gold", (1.0,0.48,0.025), 0.0, 0.25, (1.0,0.22,0.01), 4.0)

def smooth(obj):
    if obj.type == 'MESH':
        for p in obj.data.polygons:
            p.use_smooth = True
    return obj

def cyl(name, radius, depth, loc, material, vertices=96, rot=(0,math.pi/2,0)):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices, radius=radius, depth=depth,
        location=loc, rotation=rot
    )
    o = bpy.context.object
    o.name = name
    o.data.materials.append(material)
    return smooth(o)

def torus(name, major, minor, loc, material, rot=(0,math.pi/2,0)):
    bpy.ops.mesh.primitive_torus_add(
        major_radius=major, minor_radius=minor,
        major_segments=96, minor_segments=16,
        location=loc, rotation=rot
    )
    o = bpy.context.object
    o.name = name
    o.data.materials.append(material)
    return smooth(o)

def blade_mesh(name, x, angle, radius, material, width=0.22):
    # Swept, tapered blade in the YZ plane.
    verts = []
    for r, w in [(0.16,0.08),(radius*0.62,width),(radius,0.035)]:
        for side in [-1,1]:
            t = angle + side*w/max(r,0.1)
            verts.append((x, math.cos(t)*r, math.sin(t)*r))
    faces = [(0,1,3,2),(2,3,5,4)]
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(verts, [], faces)
    mesh.materials.append(material)
    obj = bpy.data.objects.new(name, mesh)
    scene.collection.objects.link(obj)
    sol = obj.modifiers.new("Blade thickness", "SOLIDIFY")
    sol.thickness = 0.045
    bevel = obj.modifiers.new("Soft machined edges", "BEVEL")
    bevel.width = 0.025
    bevel.segments = 2
    return obj

# Engine axis runs along X; intake is left, exhaust is right.
cyl("Rear engine casing", 1.12, 4.8, (0.15,0,0), titanium)
cyl("Front intake lip", 1.22, 0.22, (-2.35,0,0), steel)
cyl("Central dark core", 0.52, 4.4, (0.2,0,0), dark)
cyl("Lower protective shell", 1.13, 4.5, (0.1,0,0), dark)

for z in [-1.08,1.08]:
    bpy.ops.mesh.primitive_cube_add(size=1, location=(0.1,0,z))
    rail = bpy.context.object
    rail.name = "Cutaway titanium rim"
    rail.dimensions = (4.7,0.10,0.10)
    rail.data.materials.append(steel)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

for x,r in [(-1.35,0.93),(-0.72,0.82),(-0.10,0.72),(0.65,0.72),(1.35,0.78),(2.05,0.82)]:
    torus("Internal support ring", r, 0.045, (x,0,0), titanium)

# Intake fan
cyl("Main fan hub",0.24,0.42,(-2.05,0,0),steel)
fan_blades = []
for i in range(18):
    fan_blades.append(blade_mesh(
        "Large intake fan blade", -2.02,
        2*math.pi*i/18, 0.98, steel, 0.26
    ))

# Compressor stages
compressor_blades = []
for stage,x,r,n in [(1,-1.35,0.76,14),(2,-0.82,0.66,13),(3,-0.28,0.58,12)]:
    cyl("Compressor rotor hub",0.16,0.16,(x,0,0),titanium)
    for i in range(n):
        compressor_blades.append(blade_mesh(
            "Compressor stage %d blade" % stage, x,
            2*math.pi*i/n, r, blue, 0.12
        ))

# Combustion chamber
cyl("Combustion chamber outer",0.69,0.75,(0.75,0,0),orange)
for x in [0.36,1.12]:
    torus("Combustor glowing rim",0.66,0.055,(x,0,0),yellow)

for i in range(10):
    a = 2*math.pi*i/10
    bpy.ops.mesh.primitive_uv_sphere_add(
        segments=16, ring_count=8, radius=0.075,
        location=(0.35,0.72*math.cos(a),0.72*math.sin(a))
    )
    o = bpy.context.object
    o.name = "Fuel injector"
    o.data.materials.append(yellow)

# Turbine
turbine_blades = []
cyl("Turbine hub",0.25,0.3,(1.55,0,0),steel)
for i in range(16):
    turbine_blades.append(blade_mesh(
        "Turbine blade",1.58,2*math.pi*i/16,0.78,orange,0.15
    ))

# Exhaust nozzle and plume
torus("Exhaust nozzle rim",0.82,0.09,(2.45,0,0),steel)
cyl("Exhaust dark throat",0.74,0.55,(2.55,0,0),dark)
for j in range(3):
    bpy.ops.mesh.primitive_cone_add(
        vertices=64, radius1=0.55-j*0.10, radius2=0.12,
        depth=1.25+j*0.2, location=(3.35+j*0.45,0,0),
        rotation=(0,math.pi/2,0)
    )
    flame = bpy.context.object
    flame.name = "Layered hot exhaust"
    flame.data.materials.append(yellow if j == 0 else orange)
    flame.keyframe_insert(data_path="scale", frame=1)
    flame.scale = (1.0,1.0,1.0)
    flame.keyframe_insert(data_path="scale", frame=250)
    flame.scale = (0.75,0.75,1.25)
    flame.keyframe_insert(data_path="scale", frame=768)

# Blue intake airflow streaks
for i in range(7):
    z = (i-3)*0.19
    bpy.ops.mesh.primitive_cube_add(size=1, location=(-3.35,0,z))
    flow = bpy.context.object
    flow.name = "Blue airflow streak"
    flow.dimensions = (1.35,0.025,0.025)
    flow.data.materials.append(blue)
    flow.keyframe_insert(data_path="location", frame=1)
    flow.location.x = -2.5
    flow.keyframe_insert(data_path="location", frame=90)
    flow.location.x = -3.35
    flow.keyframe_insert(data_path="location", frame=180)

# Studio floor
bpy.ops.mesh.primitive_plane_add(size=200, location=(0,0,-1.42))
floor = bpy.context.object
floor.name = "Dark studio floor"
floor.data.materials.append(dark)

# Portrait camera
bpy.ops.object.camera_add(location=(0.0,-10.8,5.0))
cam = bpy.context.object
cam.name = "Hero camera"
target = Vector((0.35,0,0))
cam.rotation_euler = (target-cam.location).to_track_quat('-Z','Y').to_euler()
cam.data.type = 'ORTHO'
cam.data.ortho_scale = 8.5
scene.camera = cam

def point_camera(frame, loc, look):
    cam.location = loc
    cam.rotation_euler = (Vector(look)-cam.location).to_track_quat('-Z','Y').to_euler()
    cam.keyframe_insert(data_path="location", frame=frame)
    cam.keyframe_insert(data_path="rotation_euler", frame=frame)

point_camera(1,(-1.0,-8.8,3.7),(-1.0,0,0))
point_camera(90,(0,-10.8,4.8),(0.2,0,0))
point_camera(240,(0.4,-10.0,4.0),(0.4,0,0))
point_camera(430,(1.0,-9.8,3.5),(0.8,0,0))
point_camera(600,(1.7,-9.0,3.0),(1.2,0,0))
point_camera(768,(0.4,-10.8,4.8),(0.4,0,0))

# Lights
def area(name, loc, power, color, size, aim=(0,0,0)):
    bpy.ops.object.light_add(type='AREA', location=loc)
    light = bpy.context.object
    light.name = name
    light.data.energy = power
    light.data.color = color
    light.data.shape = 'DISK'
    light.data.size = size
    light.rotation_euler = (Vector(aim)-light.location).to_track_quat('-Z','Y').to_euler()

area("Cool key light",(-3,-5,6),1800,(0.35,0.62,1.0),7)
area("Warm rim light",(2,3,4),2200,(1.0,0.28,0.06),5)
area("Front softbox",(-4,1,2),1100,(0.7,0.85,1.0),4)

# Rotor animation. The legacy Action.fcurves loop was removed because
# Blender 5.0 no longer exposes Action.fcurves in the old way.
for obj in fan_blades + compressor_blades + turbine_blades:
    obj.rotation_mode = 'XYZ'
    obj.keyframe_insert(data_path="rotation_euler", frame=1)
    obj.rotation_euler.x = math.radians(360*8)
    obj.keyframe_insert(data_path="rotation_euler", frame=768)

# Compositor glow
scene.use_nodes = True
nodes = scene.node_tree.nodes
nodes.clear()
rl = nodes.new("CompositorNodeRLayers")
gl = nodes.new("CompositorNodeGlare")
gl.glare_type = 'FOG_GLOW'
gl.threshold = 1.2
gl.quality = 'MEDIUM'
out = nodes.new("CompositorNodeComposite")
scene.node_tree.links.new(rl.outputs["Image"], gl.inputs["Image"])
scene.node_tree.links.new(gl.outputs["Image"], out.inputs["Image"])

# Render all frames as render/frame_0001.png, etc.
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = os.path.abspath("render/frame_")
scene.render.use_file_extension = True
bpy.ops.render.render(animation=True)
