# Jet Engine Video Generator (Blender 5.0 compatible)

This project creates a procedural 3D jet-engine animation and a simple generated
background engine ambience/SFX bed.

## Files
- `scripts/create_scene.py` — Blender scene and animation; configured for Blender 5.0's `BLENDER_EEVEE` engine.
- `scripts/make_audio.py` — creates `render/music_sfx.wav` using Python and NumPy.

## Render
Run from this folder:
```bash
blender -b -P scripts/create_scene.py
python3 scripts/make_audio.py
```

The Blender script renders 768 PNG frames at 30 fps (25.6 seconds) into `render/`.
The GitHub Actions workflow should combine those frames with
`assets/voiceover.m4a` from the repository root.

Note: This is a starter procedural animation. It has been updated to remove the
legacy `Action.fcurves` access that failed under Blender 5.0.1. A full render has
not been validated in this environment.
