# Jet Engine Video Generator

This ZIP contains the Blender scene script and procedural music/SFX generator.

## Files
- `scripts/create_scene.py` — procedural jet-engine cutaway animation for Blender 5.0.
- `scripts/make_audio.py` — creates a quiet procedural engine ambience and transition accents.

## Important
The compositor node-tree setup has intentionally been omitted because Blender 5.0 changed that API. The scene uses emissive materials for colored airflow, combustion, and exhaust.

The render script writes PNG frames to `render/frame_0001.png` onward at 1080x1920, 30 fps, 25.6 seconds.
